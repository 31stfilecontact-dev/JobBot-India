# === ADD to models.py ===
# 1. New fields on the existing Job class — add these lines inside class Job(db.Model):

    role_category = db.Column(db.String(100))          # e.g. "Corporate Tax", "Direct Tax", "GST"
    exp_min_years = db.Column(db.Float)                 # parsed from JD, best-effort
    exp_max_years = db.Column(db.Float)

# 2. New fields on the existing Profile class — add these lines inside class Profile(db.Model):

    exp_filter_min = db.Column(db.Float, default=0)     # user's desired experience range filter
    exp_filter_max = db.Column(db.Float, default=99)
    role_filter = db.Column(db.String(200), default="") # comma-separated role/title keywords to match

# 3. New standalone model — add this as a new class anywhere in models.py

class TrackedCompany(db.Model):
    """Companies the user wants to search directly on their own careers
    portal (Greenhouse/Lever board token, or a generic careers page URL)."""
    id = db.Column(db.Integer, primary_key=True)
    display_name = db.Column(db.String(200), nullable=False)
    ats_type = db.Column(db.String(50))       # greenhouse / lever / generic
    board_token = db.Column(db.String(200))   # greenhouse/lever slug, if applicable
    career_url = db.Column(db.String(1000))   # used for generic fallback, or informational for ATS ones
    added_at = db.Column(db.DateTime, default=db.func.now())

    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}
