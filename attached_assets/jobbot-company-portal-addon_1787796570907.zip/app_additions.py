# === ADD to app.py ===
# Add these imports near the top, alongside the existing scraper imports:

from scrapers.company_portal import (
    fetch_greenhouse_jobs, fetch_lever_jobs, fetch_generic_career_page_jobs, parse_experience_range
)
from models import TrackedCompany  # add TrackedCompany to the existing "from models import ..." line instead


# === Manage tracked companies ===

@app.route("/portals", methods=["GET"])
def portals():
    companies = TrackedCompany.query.order_by(TrackedCompany.added_at.desc()).all()
    return render_template("portals.html", companies=companies)


@app.route("/portals/add", methods=["POST"])
def portals_add():
    name = request.form.get("display_name", "").strip()
    ats_type = request.form.get("ats_type", "generic")
    board_token = request.form.get("board_token", "").strip()
    career_url = request.form.get("career_url", "").strip()

    if not name:
        flash("Company name is required.")
        return redirect(url_for("portals"))

    company = TrackedCompany(
        display_name=name, ats_type=ats_type,
        board_token=board_token or None, career_url=career_url or None,
    )
    db.session.add(company)
    db.session.commit()
    flash(f"Added {name} to tracked companies.")
    return redirect(url_for("portals"))


@app.route("/portals/<int:company_id>/delete", methods=["POST"])
def portals_delete(company_id):
    company = TrackedCompany.query.get_or_404(company_id)
    db.session.delete(company)
    db.session.commit()
    return redirect(url_for("portals"))


# === Search tracked companies' own portals directly ===

@app.route("/portals/search", methods=["POST"])
def portals_search():
    companies = TrackedCompany.query.all()
    added = 0
    for company in companies:
        if company.ats_type == "greenhouse" and company.board_token:
            results = fetch_greenhouse_jobs(company.board_token)
        elif company.ats_type == "lever" and company.board_token:
            results = fetch_lever_jobs(company.board_token)
        elif company.career_url:
            results = fetch_generic_career_page_jobs(company.career_url, company.display_name)
        else:
            continue

        for r in results:
            if not r.get("job_url"):
                continue
            exists = Job.query.filter_by(job_url=r["job_url"]).first()
            if exists:
                continue
            exp_min, exp_max = parse_experience_range(r.get("raw_content", ""))
            job = Job(
                title=r.get("title", "Unknown"),
                company=company.display_name,
                location=r.get("location", ""),
                source="company_portal",
                job_url=r.get("job_url"),
                career_page_url=r.get("job_url"),
                ats_type=r.get("ats_type"),
                exp_min_years=exp_min,
                exp_max_years=exp_max,
                status="new",
            )
            db.session.add(job)
            added += 1
    db.session.commit()
    flash(f"Company portal search complete — {added} new jobs added.")
    return redirect(url_for("index"))


# === REPLACE the existing index() route with this version ===
# (adds role + experience filtering on top of the existing status filter)

@app.route("/")
def index():
    status_filter = request.args.get("status", "new")
    role_filter = request.args.get("role", "").strip()
    exp_min = request.args.get("exp_min", type=float)
    exp_max = request.args.get("exp_max", type=float)

    query = Job.query
    if status_filter != "all":
        query = query.filter_by(status=status_filter)
    if role_filter:
        query = query.filter(Job.title.ilike(f"%{role_filter}%"))

    jobs = query.order_by(Job.discovered_at.desc()).all()

    # experience filtering done in Python since ranges can be partial (None on either side)
    if exp_min is not None or exp_max is not None:
        def in_range(job):
            if job.exp_min_years is None and job.exp_max_years is None:
                return True  # unknown experience — don't hide it, just can't confirm fit
            lo = job.exp_min_years if job.exp_min_years is not None else 0
            hi = job.exp_max_years if job.exp_max_years is not None else 99
            want_lo = exp_min if exp_min is not None else 0
            want_hi = exp_max if exp_max is not None else 99
            return lo <= want_hi and hi >= want_lo
        jobs = [j for j in jobs if in_range(j)]

    counts = {
        "new": Job.query.filter_by(status="new").count(),
        "applied": Job.query.filter_by(status="applied").count(),
        "failed": Job.query.filter_by(status="failed").count(),
        "skipped": Job.query.filter_by(status="skipped").count(),
    }
    return render_template(
        "index.html", jobs=jobs, counts=counts, status_filter=status_filter,
        role_filter=role_filter, exp_min=exp_min, exp_max=exp_max, profile=get_profile()
    )
