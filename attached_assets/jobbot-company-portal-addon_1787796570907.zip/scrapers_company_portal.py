"""
Company Portal search — pulls open roles DIRECTLY from a company's own
careers page, rather than from aggregators like Naukri/LinkedIn/Indeed.

Greenhouse and Lever (the same two ATSes the autofill/ module already
knows how to submit applications to) both expose free, structured public
JSON APIs per company. That makes this far more reliable than scraping
HTML: no selectors to maintain, no blocking, no JS rendering needed.

For companies on other ATSes (Workday, custom portals, etc.) we fall back
to a best-effort HTML scrape of the careers page for job titles + links.
"""
import re
import requests
from bs4 import BeautifulSoup

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}


def fetch_greenhouse_jobs(board_token: str):
    """board_token is the company's Greenhouse slug, e.g. for
    boards.greenhouse.io/stripe the token is 'stripe'."""
    url = f"https://boards-api.greenhouse.io/v1/boards/{board_token}/jobs?content=true"
    try:
        resp = requests.get(url, headers=HEADERS, timeout=15)
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        print(f"[company_portal] greenhouse fetch failed for {board_token}: {e}")
        return []

    jobs = []
    for job in data.get("jobs", []):
        jobs.append({
            "title": job.get("title"),
            "company": board_token,
            "location": (job.get("location") or {}).get("name", ""),
            "job_url": job.get("absolute_url"),
            "source": "company_portal",
            "ats_type": "greenhouse",
            "raw_content": job.get("content", ""),  # used for experience parsing
        })
    return jobs


def fetch_lever_jobs(site_slug: str):
    """site_slug is the company's Lever slug, e.g. for jobs.lever.co/netflix
    the slug is 'netflix'."""
    url = f"https://api.lever.co/v0/postings/{site_slug}?mode=json"
    try:
        resp = requests.get(url, headers=HEADERS, timeout=15)
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        print(f"[company_portal] lever fetch failed for {site_slug}: {e}")
        return []

    jobs = []
    for job in data:
        jobs.append({
            "title": job.get("text"),
            "company": site_slug,
            "location": (job.get("categories") or {}).get("location", ""),
            "job_url": job.get("hostedUrl"),
            "source": "company_portal",
            "ats_type": "lever",
            "raw_content": job.get("descriptionPlain", ""),
        })
    return jobs


def fetch_generic_career_page_jobs(career_url: str, company_name: str):
    """Best-effort fallback for companies on Workday or a custom portal.
    No structured API available, so this scrapes <a> tags that look like
    job listing links. Accuracy varies a lot by site — treat results as
    a starting point, not exhaustive."""
    try:
        resp = requests.get(career_url, headers=HEADERS, timeout=15)
        resp.raise_for_status()
    except Exception as e:
        print(f"[company_portal] generic fetch failed for {career_url}: {e}")
        return []

    soup = BeautifulSoup(resp.text, "lxml")
    jobs = []
    seen_urls = set()
    for a in soup.find_all("a", href=True):
        text = a.get_text(strip=True)
        href = a["href"]
        # heuristic: job listing links usually have decent-length link text
        # and the href often contains job/career/position/req-style paths
        if len(text) < 6 or len(text) > 120:
            continue
        if not re.search(r"job|career|position|req|opening", href, re.I) and \
           not re.search(r"engineer|manager|analyst|associate|lead|executive|officer|consultant|specialist", text, re.I):
            continue
        full_url = href if href.startswith("http") else requests.compat.urljoin(career_url, href)
        if full_url in seen_urls:
            continue
        seen_urls.add(full_url)
        jobs.append({
            "title": text,
            "company": company_name,
            "location": "",
            "job_url": full_url,
            "source": "company_portal",
            "ats_type": "unknown",
            "raw_content": "",
        })
    return jobs[:30]  # cap — generic scraping is noisy, avoid flooding the job list


def parse_experience_range(text: str):
    """Best-effort extraction of an experience range (in years) from a job
    description, e.g. '3-5 years', '5+ yrs experience', '2 to 4 Years'.
    Returns (min_years, max_years) or (None, None) if nothing found."""
    if not text:
        return None, None
    text = text.lower()

    m = re.search(r"(\d+)\s*(?:-|to)\s*(\d+)\s*\+?\s*(?:years|yrs)", text)
    if m:
        return float(m.group(1)), float(m.group(2))

    m = re.search(r"(\d+)\s*\+\s*(?:years|yrs)", text)
    if m:
        return float(m.group(1)), None

    m = re.search(r"minimum\s*(?:of\s*)?(\d+)\s*(?:years|yrs)", text)
    if m:
        return float(m.group(1)), None

    return None, None
